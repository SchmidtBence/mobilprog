package hu.uni.miskolc.mobilprog_beadando.product.model;

import java.io.Serializable;
import java.util.UUID;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity(tableName = "Product")
public class Product implements Serializable {

    @PrimaryKey
    @NonNull
    private UUID id;
    private String name;
    private int amount;
    private int weight;
    private String manufacturer;

    @Ignore
    public Product() {
        this.id = id.randomUUID();
    }

    public Product(String name, int amount, int weight, String manufacturer) {
        this.id = id.randomUUID();
        this.name = name;
        this.amount = amount;
        this.weight = weight;
        this.manufacturer = manufacturer;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    @Override
    public String toString() {
        return "Product{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", amount=" + amount +
                ", weight=" + weight +
                ", manufacturer='" + manufacturer + '\'' +
                '}';
    }
}
