package hu.uni.miskolc.mobilprog_beadando.ui;

import android.view.View;

public interface HajoKivalasztListener {

    void onHajoClick(int position, View v);

    void onHajoClickDelete(int position, View v);
}
