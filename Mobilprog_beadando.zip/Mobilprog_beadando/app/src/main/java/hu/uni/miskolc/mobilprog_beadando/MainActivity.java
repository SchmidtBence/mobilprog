package hu.uni.miskolc.mobilprog_beadando;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;

import hu.uni.miskolc.mobilprog_beadando.ProductDetails.HajoListActivity;
import hu.uni.miskolc.mobilprog_beadando.product.StoreDataActivity;

public class MainActivity extends AppCompatActivity {
    int CAMERA_IMAGE_REQUEST = 101;
    int PERMISION_REQUEST_CODE = 1;
    private Button hajokButton;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());
        Button cambtn = findViewById(R.id.button);
        hajokButton = findViewById(R.id.hajokButton);
        Intent intent=getIntent();
        String nev=intent.getStringExtra("nev");
        TextView text=findViewById(R.id.textView);
        text.setText(nev);
        if(checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED){
            cambtn.setEnabled(true);
        }else{
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.CAMERA}, PERMISION_REQUEST_CODE);
        }

        hajokButton.setOnClickListener(view -> {
            Intent intent2 = new Intent(MainActivity.this, HajoListActivity.class);
            startActivity(intent2);
        });
    }

    public void goToProductData(View view) {
        Intent intent = new Intent(MainActivity.this, StoreDataActivity.class);
        startActivity(intent);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        Button cambtn = findViewById(R.id.camera);
        if(requestCode == PERMISION_REQUEST_CODE){
            for (int i = 0; i < permissions.length; i++) {
                if(permissions[i] == Manifest.permission.CAMERA  && grantResults[i] == PackageManager.PERMISSION_GRANTED){
                    Toast.makeText(MainActivity.this, "Permision for camera usafes", Toast.LENGTH_SHORT).show();
                    cambtn.setEnabled(true);
                }
            }
        }
    }


    public void camerastart(View view){
        Intent takepicture = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "image.jpg");
        takepicture.putExtra(MediaStore.EXTRA_OUTPUT,Uri.fromFile(file));
        startActivityForResult(takepicture, CAMERA_IMAGE_REQUEST);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == CAMERA_IMAGE_REQUEST) {
            if (resultCode == RESULT_OK) {
                System.out.println("siker");
            }
        }
    }

}