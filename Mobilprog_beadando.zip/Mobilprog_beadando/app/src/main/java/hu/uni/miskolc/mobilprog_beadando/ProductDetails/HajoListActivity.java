package hu.uni.miskolc.mobilprog_beadando.ProductDetails;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.android.volley.*;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


import hu.uni.miskolc.mobilprog_beadando.R;
import hu.uni.miskolc.mobilprog_beadando.Service.HajoDTO;
import hu.uni.miskolc.mobilprog_beadando.Service.HajoService;
import hu.uni.miskolc.mobilprog_beadando.ui.HajoAdapter;
import hu.uni.miskolc.mobilprog_beadando.ui.HajoKivalasztListener;
import hu.uni.miskolc.mobilprog_beadando.ui.HajoViewModel;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


public class HajoListActivity extends AppCompatActivity {

    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hajo_list);
        recyclerView = findViewById(R.id.reyclerView);
    }

    @Override
    protected void onStart() {
        super.onStart();
        RequestQueue sor = Volley.newRequestQueue(this);
        String url = "https://dog.ceo/api/breeds/image/random";

        Request jsonObjectRequest = new JsonObjectRequest(
                url,
                response -> {
                    try {
                        String imageURL = response.getString("message");
                        System.out.println(imageURL);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                },
                error -> {
                });
        sor.add(jsonObjectRequest);

        //Retrofit
        Retrofit retrofit = new Retrofit.Builder().
                baseUrl("https://my-json-server.typicode.com/SchmidtBence/db/").addConverterFactory(GsonConverterFactory.create()).build();

        HajoService service = retrofit.create(HajoService.class);

        Call<List<HajoDTO>> hajoklistazasa = service.hajoklistazasa();
        hajoklistazasa.enqueue(new Callback<List<HajoDTO>>() {
            @Override
            public void onResponse(Call<List<HajoDTO>> call, Response<List<HajoDTO>> response) {
                System.out.println(response.body());
            }

            @Override
            public void onFailure(Call<List<HajoDTO>> call, Throwable t) {

            }
        });

        Call<HajoDTO> egyTermek = service.hajokereses(1);

        egyTermek.enqueue(new Callback<HajoDTO>() {
            @Override
            public void onResponse(Call<HajoDTO> call, Response<HajoDTO> response) {
                if (response.body() == null) {
                    System.out.println("Az adott azonosítóval nem létezik hajó");

                } else {
                    System.out.println(response.body());
                }
            }

            @Override
            public void onFailure(Call<HajoDTO> call, Throwable t) {
                System.out.println("Something went wrong");
            }
        });

        HajoDTO hajo = new HajoDTO();
        hajo.setId(2);
        hajo.setName("Béla");
        hajo.setTipus("Cirkáló");
        hajo.setErtek(30000);
        Call<HajoDTO> hajoletrehozas = service.hajoletrehozas(hajo);
        hajoletrehozas.enqueue(new Callback<HajoDTO>() {
            @Override
            public void onResponse(Call<HajoDTO> call, Response<HajoDTO> response) {
                if (response.code() == 200 || response.code() == 201){
                    System.out.println(response.code()+" "+ response.body());
                }
                else if(response.errorBody() != null){
                    try {
                        System.out.println(response.errorBody().string());
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<HajoDTO> call, Throwable t) {

            }
        });

        Call<List<HajoDTO>> hajoertekel = service.hajoadottertektol(30000);
        hajoertekel.enqueue(new Callback<List<HajoDTO>>() {
            @Override
            public void onResponse(Call<List<HajoDTO>> call, Response<List<HajoDTO>> response) {
                System.out.println(response.body());
            }

            @Override
            public void onFailure(Call<List<HajoDTO>> call, Throwable t) {

            }
        });


        //RecyclerView létrehozása
        RecyclerView.LayoutManager layoutManager =
                new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);

        DividerItemDecoration dividerItemDecoration =
                new DividerItemDecoration(
                        recyclerView.getContext(),
                        DividerItemDecoration.VERTICAL);
        recyclerView.addItemDecoration(dividerItemDecoration);

        HajoViewModel vm = new ViewModelProvider(this).get(HajoViewModel.class);

        HajoAdapter adapter = new HajoAdapter();
        adapter.setHajok(new ArrayList<>());
        recyclerView.setAdapter(adapter);

        vm.getDolgozok().observe(this, hajok -> {
            adapter.setHajok(hajok);
            adapter.setListener(new HajoKivalasztListener() {
                @Override
                public void onHajoClick(int position, View v) {


                    Intent intent = new Intent(
                            HajoListActivity.this, HajoDetailsActivity.class);
                    HajoDTO hajo = hajok.get(position);
                    intent.putExtra("hajo",hajo);
                    startActivity(intent);
                }

                @Override
                public void onHajoClickDelete(int position, View v) {
                    System.out.println("Törlendő hajo azonositója "+hajok.get(position).getId());
                    vm.deleteDolgozo(hajok.get(position));
                }
            });
            recyclerView.setAdapter(adapter);
        });
    }
}