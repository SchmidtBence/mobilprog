package hu.uni.miskolc.mobilprog_beadando.ui;



import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.List;

import hu.uni.miskolc.mobilprog_beadando.Service.HajoDTO;
import hu.uni.miskolc.mobilprog_beadando.Service.HajoService;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class HajoViewModel extends ViewModel {

    private MutableLiveData<List<HajoDTO>> hajok;


    public LiveData<List<HajoDTO>> getDolgozok() {
        if (hajok == null){
            hajok = new MutableLiveData<>();
            loadHajok();
        }
        return hajok;
    }

    public void deleteDolgozo(HajoDTO hajoDTO){
        hajok.getValue().remove(hajoDTO);
        hajok.postValue(hajok.getValue());

        }

    public void loadHajok(){
        Retrofit retrofit = new Retrofit.Builder().
                baseUrl("https://my-json-server.typicode.com/SchmidtBence/db/").addConverterFactory(GsonConverterFactory.create()).build();

        HajoService service = retrofit.create(HajoService.class);

        Call<List<HajoDTO>> hajoklistazasa = service.hajoklistazasa();
        hajoklistazasa.enqueue(new Callback<List<HajoDTO>>() {
            @Override
            public void onResponse(Call<List<HajoDTO>> call, Response<List<HajoDTO>> response) {
                System.out.println(response.body());
                hajok.postValue(response.body());
            }

            @Override
            public void onFailure(Call<List<HajoDTO>> call, Throwable t) {

            }
        });

    }
}
