package hu.uni.miskolc.mobilprog_beadando.Service;

import java.io.Serializable;

public class HajoDTO implements Serializable {

    public int id;
    public String name;
    public String tipus;
    public int ertek;

    public HajoDTO() {
    }

    public HajoDTO(int id, String name, String tipus, int ertek) {
        this.id = id;
        this.name = name;
        this.tipus = tipus;
        this.ertek = ertek;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTipus() {
        return tipus;
    }

    public void setTipus(String tipus) {
        this.tipus = tipus;
    }

    public int getErtek() {
        return ertek;
    }

    public void setErtek(int ertek) {
        this.ertek = ertek;
    }

    @Override
    public String toString() {
        return "HajoDTO{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", tipus='" + tipus + '\'' +
                ", ertek=" + ertek +
                '}';
    }
}
