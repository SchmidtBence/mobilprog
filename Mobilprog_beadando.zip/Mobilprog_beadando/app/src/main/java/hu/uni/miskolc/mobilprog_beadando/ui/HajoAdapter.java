package hu.uni.miskolc.mobilprog_beadando.ui;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import hu.uni.miskolc.mobilprog_beadando.R;
import hu.uni.miskolc.mobilprog_beadando.Service.HajoDTO;


public class HajoAdapter extends
        RecyclerView.Adapter<HajoViewHolder> {

    private List<HajoDTO> hajok;
    private HajoKivalasztListener listener;

    public void setHajok(List<HajoDTO> hajok) {
        this.hajok = hajok;
    }

    public void setListener(HajoKivalasztListener listener) {
        this.listener = listener;
    }

    @NonNull
    @Override
    public HajoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LinearLayout layout = (LinearLayout) LayoutInflater.from(parent.getContext()).inflate(
                R.layout.hajo_sor, parent,
                false);
        HajoViewHolder vh = new HajoViewHolder(layout, listener);

        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull HajoViewHolder holder, int position) {
        HajoDTO hajo =
                hajok.get(position);
        holder.azonosito.setText(String.valueOf(hajo.getId()));
        holder.Nev.setText(hajo.getName());
        holder.Tipus.setText(hajo.getTipus());

    }

    @Override
    public int getItemCount() {
        return hajok.size();
    }
}
