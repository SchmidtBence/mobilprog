package hu.uni.miskolc.mobilprog_beadando.ProductDetails;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;


import hu.uni.miskolc.mobilprog_beadando.Service.HajoDTO;
import hu.uni.miskolc.mobilprog_beadando.databinding.ActivityHajoDetailsBinding;


public class HajoDetailsActivity extends AppCompatActivity {

    private ActivityHajoDetailsBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityHajoDetailsBinding.inflate(
                getLayoutInflater());
        setContentView(binding.getRoot());
    }

    @Override
    protected void onStart() {
        super.onStart();
        HajoDTO hajoDTO = (HajoDTO) getIntent().
                getSerializableExtra("hajo");
        if (hajoDTO != null) {
            binding.idtext.setText(
                    String.valueOf(hajoDTO.getId()));
            binding.nevText.setText(
                    hajoDTO.getName());
            binding.tipusText.setText(
                    hajoDTO.getTipus());
            binding.ertekText.setText(
                    String.valueOf(hajoDTO.getErtek()));
        }
    }
}