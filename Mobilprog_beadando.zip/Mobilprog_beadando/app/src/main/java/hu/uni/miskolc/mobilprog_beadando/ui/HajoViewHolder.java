package hu.uni.miskolc.mobilprog_beadando.ui;

import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import hu.uni.miskolc.mobilprog_beadando.R;

public class HajoViewHolder
        extends RecyclerView.ViewHolder implements View.OnClickListener {

    protected TextView azonosito;
    protected TextView Nev;
    protected TextView Tipus;
    protected HajoKivalasztListener listener;
    protected ImageButton torlesGomb;
    protected ImageButton nezesGomb;

    public HajoViewHolder(@NonNull View itemView, HajoKivalasztListener listener) {
        super(itemView);
        this.azonosito = itemView.findViewById(R.id.azonosito);
        this.Nev = itemView.findViewById(R.id.Tipus);
        this.Tipus = itemView.findViewById(R.id.Nev);
        this.torlesGomb = itemView.findViewById(R.id.torlesGomb);
        this.nezesGomb = itemView.findViewById(R.id.nezesGomb);
        this.listener = listener;
        itemView.setOnClickListener(this);
        this.torlesGomb.setOnClickListener(this);
        this.nezesGomb.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if (view == torlesGomb) {
            listener.onHajoClickDelete(getAdapterPosition(), view);
        } else if(view == nezesGomb){
            listener.onHajoClick(getAdapterPosition(), view);
        }
        else{

            if (this.torlesGomb.getVisibility() == View.INVISIBLE) {
                this.torlesGomb.setVisibility(View.VISIBLE);
            } else {
                this.torlesGomb.setVisibility(View.INVISIBLE);
            }
        }

        //Itt mondjuk meg, mit csináljunk, amikor rákattintottunk
    }
}
