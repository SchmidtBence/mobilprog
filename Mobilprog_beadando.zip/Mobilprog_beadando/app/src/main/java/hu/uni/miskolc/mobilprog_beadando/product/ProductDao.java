package hu.uni.miskolc.mobilprog_beadando.product;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import java.util.List;

import hu.uni.miskolc.mobilprog_beadando.product.model.Product;

@Dao
public interface ProductDao {
    @Query("SELECT * FROM Product")
    List<Product> getAll();

    @Query("SELECT * FROM Product WHERE amount > :number")
    List<Product> getProductWithAmountGreaterThan(int number);

    @Query("SELECT * FROM Product WHERE Name =:Name AND Amount =:Amount AND Weight =:Weight AND Manufacturer =:Manufacturer")
    List<Product> findSame(String Name, int Amount, int Weight, String Manufacturer);

    default List<Product> findSame(Product product) {
        return findSame(product.getName(), product.getAmount(), product.getWeight(), product.getManufacturer());
    }

    @Insert
    void insert(Product product);

    @Delete
    void delete(Product product);

    @Update
    void update(Product product);
}
