package hu.uni.miskolc.mobilprog_beadando.product;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;


import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLOutput;

import hu.uni.miskolc.mobilprog_beadando.MainActivity;
import hu.uni.miskolc.mobilprog_beadando.R;
import hu.uni.miskolc.mobilprog_beadando.product.model.Product;

public class StoreDataActivity extends AppCompatActivity {

    private EditText name;
    private EditText manufacturer;
    private CheckBox conditions;
    private EditText amount;
    private EditText weight;

    private Button saveButton;

    private ProductDao productDao;
    private ProductDatabase productDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_data);


        name = findViewById(R.id.NameText);
        manufacturer = findViewById(R.id.manufacturerText);
        amount = findViewById(R.id.Amount);
        weight = findViewById(R.id.Weight);
        conditions = findViewById(R.id.checkBox);
        saveButton = findViewById(R.id.Send);

        StrictMode.VmPolicy.Builder builder =
                new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());
        productDatabase = Room.databaseBuilder(getApplicationContext(), ProductDatabase.class, "products").build();
        productDao = productDatabase.productDao();

        conditions.setOnCheckedChangeListener((compoundButton, b) -> {
            if (b) {
                saveButton.setEnabled(true);
            } else {
                saveButton.setEnabled(false);
            }
        });
        saveButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                ViewGroup dataLayout = findViewById(R.id.dataLayout);
                if (formInputControll(dataLayout)) {
                    Product product = new Product(
                            name.getText().toString(),
                            Integer.parseInt(amount.getText().toString()),
                            Integer.parseInt(weight.getText().toString()),
                            manufacturer.getText().toString()
                    );
                    StringBuilder sb = new StringBuilder();
                    sb.append(product.getName());
                    sb.append(" ");
                    sb.append(product.getManufacturer());
                    sb.append(" ");
                    sb.append(product.getAmount());
                    sb.append(" ");
                    sb.append(product.getWeight());

                    File file = new File(getExternalFilesDir("") + "/products.txt");

                    try {
                        FileWriter writer = new FileWriter(file, true);
                        writer.write(sb.toString());
                        writer.append("\n");
                        writer.flush();
                        writer.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }


                    AsyncTask.execute(new Runnable() {
                        @Override
                        public void run() {
                            if(productDao.findSame(product).size() == 0) {
                                productDao.insert(product);
                                File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS),"databaseContent.txt");
                                try {
                                    FileWriter writer = new FileWriter(file, false);
                                    writer.write(productDao.getAll().toString());
                                    writer.flush();
                                    writer.close();
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    name.setText(null);
                                    manufacturer.setText(null);
                                    amount.setText(null);
                                    weight.setText(null);
                                    conditions.setChecked(false);
                                    amount.clearFocus();
                                    weight.clearFocus();
                                }
                            });
                        }

                    });

                }
                EditText productName=findViewById(R.id.NameText);
                Intent intent=new Intent(StoreDataActivity.this,MainActivity.class);
                intent.putExtra("nev",productName.getText().toString());
                startActivity(intent);
            }
        });

    }
    private boolean formInputControll(ViewGroup layout) {
        boolean result = true;
        int count = layout.getChildCount();
        for (int i = 0; i < count; i++) {
            View child = layout.getChildAt(i);
            if (child instanceof EditText) {
                EditText editText = (EditText) child;
                int inputType = editText.getInputType();
                if (editText.getText().toString().trim().isEmpty()) {
                    result = false;
                    editText.setError("Kötelező!");
                }
            }
        }
        return result;
    }
}
