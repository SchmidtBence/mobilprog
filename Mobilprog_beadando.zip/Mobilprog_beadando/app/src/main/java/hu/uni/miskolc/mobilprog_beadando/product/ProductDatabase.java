package hu.uni.miskolc.mobilprog_beadando.product;

import androidx.room.Database;
import androidx.room.RoomDatabase;

import hu.uni.miskolc.mobilprog_beadando.product.model.Product;

@Database(entities = {Product.class}, version = 1)
public abstract class ProductDatabase extends RoomDatabase {
    public abstract ProductDao productDao();
}
